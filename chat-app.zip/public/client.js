const socket = io();
const form = document.getElementById("form");
const input = document.getElementById("input");
const messages = document.getElementById("messages");
const nicknameInput = document.getElementById("nickname");
const tagInput = document.getElementById("tag");

form.addEventListener("submit", (e) => {
  e.preventDefault();
  if (input.value && nicknameInput.value && tagInput.value) {
    const msgData = {
      nickname: nicknameInput.value,
      tag: tagInput.value,
      text: input.value,
      time: new Date().toLocaleTimeString("ko-KR", { hour: "2-digit", minute: "2-digit" })
    };
    socket.emit("chat message", msgData);
    input.value = "";
  }
});

socket.on("chat message", (msgData) => {
  const item = document.createElement("li");

  const meta = document.createElement("div");
  meta.classList.add("meta");
  meta.textContent = `${msgData.nickname} ${msgData.tag} • ${msgData.time}`;

  const text = document.createElement("div");
  text.textContent = msgData.text;

  item.appendChild(meta);
  item.appendChild(text);
  messages.appendChild(item);
  messages.scrollTop = messages.scrollHeight;
});